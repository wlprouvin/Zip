const express = require('express');
const fs = require('fs');
const useragent = require('useragent');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'html');
app.set('views', './views');

const logsFile = 'logs.json';

function saveLog(data) {
  const logs = fs.existsSync(logsFile) ? JSON.parse(fs.readFileSync(logsFile)) : [];
  logs.push(data);
  fs.writeFileSync(logsFile, JSON.stringify(logs, null, 2));
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/views/index.html');
});

app.get('/r/:id', (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const agent = useragent.parse(req.headers['user-agent']);
  const ref = req.get('Referrer') || 'Direto';
  saveLog({
    tipo: 'link',
    ip,
    navegador: agent.toString(),
    origem: ref,
    horario: new Date().toLocaleString()
  });
  res.redirect('https://www.google.com');
});

app.get('/pixel.png', (req, res) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const agent = useragent.parse(req.headers['user-agent']);
  const ref = req.get('Referrer') || 'Imagem externa';
  saveLog({
    tipo: 'pixel',
    ip,
    navegador: agent.toString(),
    origem: ref,
    horario: new Date().toLocaleString()
  });
  const img = fs.readFileSync('./public/pixel.png');
  res.writeHead(200, {
    'Content-Type': 'image/png',
    'Content-Length': img.length
  });
  res.end(img);
});

app.get('/logs', (req, res) => {
  const logs = fs.existsSync(logsFile) ? JSON.parse(fs.readFileSync(logsFile)) : [];
  res.send(`<h1>Logs</h1><pre>${JSON.stringify(logs, null, 2)}</pre>`);
});

app.listen(PORT, () => {
  console.log(`Servidor rodando: http://localhost:${PORT}`);
});